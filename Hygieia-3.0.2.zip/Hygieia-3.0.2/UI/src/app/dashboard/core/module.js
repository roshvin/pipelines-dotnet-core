(function () {
    'use strict';

    // create the core module
    angular.module(HygieiaConfig.module + '.core', []);
})();