package com.capitalone.dashboard.common;

import java.util.Arrays;
import java.util.List;

public class TestConstants {

    public static final List<String> SERVICE_ACCOUNTS = Arrays.asList("Service Accounts", "UNIX");

    public static final List<String> USER_ACCOUNTS = Arrays.asList("User Accounts");
}
